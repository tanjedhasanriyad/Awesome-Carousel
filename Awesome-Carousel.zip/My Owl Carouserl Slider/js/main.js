$(document).ready(function(){
	
	$("#banner-slider-demo-8").owlCarousel({autoPlay:true,lazyLoad:true, stopOnHover: true,pagination: true, navigation: false,slideSpeed : 500,paginationSpeed : 500,singleItem:true,transitionStyle : "backSlide"});
	
});